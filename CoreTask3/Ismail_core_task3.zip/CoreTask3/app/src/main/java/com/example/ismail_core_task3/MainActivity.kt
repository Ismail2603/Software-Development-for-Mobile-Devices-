package com.example.ismail_core_task3

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.opencsv.CSVReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: GroupAdapter
    private var groupList: List<Group> = listOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Load data from CSV
        groupList = readCsvFile()

        // Set up adapter
        adapter = GroupAdapter(groupList)
        recyclerView.adapter = adapter
    }

    private fun readCsvFile(): List<Group> {
        val inputStream = resources.openRawResource(R.raw.groups)
        val reader = CSVReader(InputStreamReader(inputStream))
        val groups = mutableListOf<Group>()
        reader.use {
            it.readAll().drop(1).forEach { line ->
                val group = Group(line[0], line[1], line[2])
                groups.add(group)
            }
        }
        return groups.sortedBy { it.dateTime } // Sort by date/time
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_sort -> {
                sortListByColor()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun sortListByColor() {
        val sortedGroups = groupList.sortedWith(compareBy { getColorCode(it.name) })
        adapter.updateList(sortedGroups)
    }

    private fun getColorCode(name: String): Int {
        return when (name) {
            "Apolitical" -> 0 // Green
            "Football" -> 1 // Red
            "UN Students" -> 2 // Blue
            "XSPORTS" -> 3 // Light Gray
            else -> 4 // Default White
        }
    }
}